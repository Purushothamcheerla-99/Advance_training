package Problem_Statement2_2;
import java.util.Scanner;
class Fibonacci
{
	public static void main(String[] args)
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the numbers");
	int count = 15;
	int i =sc.nextInt();
	int j =sc.nextInt();
	
	
	System.out.println("Fibonacci series is ");
	for(int c = 1;c < count ; ++c) {
		 System.out.print(i + ", ");
		 
		 int nextTerm = i + j;
		 i = j;
		 j = nextTerm;
	sc.close();	 
	}
	
	
	}
	
}