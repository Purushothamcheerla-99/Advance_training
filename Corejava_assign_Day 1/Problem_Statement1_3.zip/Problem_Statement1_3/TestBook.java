package Problem_Statement1_3;
import java.util.Scanner;

public class TestBook {
	 public static void main (String[] args) {
	        Scanner sc=new Scanner(System.in);
	        
	        System.out.println("Enter the Book name:");
	        String bookname1=sc.nextLine();
	       
	        System.out.println("Enter the price:");
	        float price1=sc.nextFloat();
	        sc.nextLine();
	        
	        System.out.println("Enter the Book name:");
	        String bookname2=sc.nextLine();
	       
	        System.out.println("Enter the price:");
	        float price2=sc.nextFloat();
	        sc.nextLine();
	       
	        
	        
	        Book obj1=new Book();
	        obj1.setBookName(bookname1);
	        obj1.setBookPrice(price1);
	        System.out.println("Book Details");
	        System.out.println("Book Name :"+obj1.getBookName());
	        System.out.println("Book Price :"+obj1.getBookPrice());
	        
	        Book obj2=new Book();
	        obj2.setBookName(bookname2);
	        obj2.setBookPrice(price2);
	        System.out.println("Book Details");
	        System.out.println("Book Name :"+obj2.getBookName());
	        System.out.println("Book Price :"+obj2.getBookPrice());
	        
	        
	        
	       sc.close();
	    }
}
