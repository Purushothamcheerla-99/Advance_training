package Problem_Statement2_3;

import java.util.Arrays;

public class Array {
	public static void main(String[] args) {

		   int[] arr = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0 };
		   System.out.println("Original Array : "+Arrays.toString(arr));
		   int sum = 0;  
	        //Loop through the array to calculate sum of elements  
	        for (int i = 0; i < arr.length; i++) {  
	           sum = sum + arr[i];  
	        } 
	        int Index_position = 15;
	        arr[Index_position] = sum;
	        System.out.println("New Array: "+Arrays.toString(arr));
	        
	        double average = sum / arr.length;
	        int Index_position1 = 16;
	        arr[Index_position1] = (int) average;
	        System.out.println("New Array: "+Arrays.toString(arr));
	        
	        
	        int Index_position2 = 17;
	        arr[Index_position2] = getSmallest(arr);
              System.out.println("New Array: "+Arrays.toString(arr));
	}

	private static int getSmallest(int[] arr) {
		
		return 0;
		 
	}
	}
