package Problem_Statement6_3;

import java.util.LinkedList;
public class TestEmployeeCollection {
	public static void main(String[] args) {
		LinkedList<Employee> L = addInput();
		display(L);
		}

	private static LinkedList <Employee> addInput() {
		// TODO Auto-generated method stub
		return null;
	}

	private static void display(LinkedList<Employee> L) {
		// TODO Auto-generated method stub
		
	
		Employee e1=new Employee (101,"bhavani", "Mallethula");
		Employee e2=new Employee (102,"srlekha", "kakani");
		Employee e3=new Employee (103,"akanksha","pasikanti");
		LinkedList<Employee> L1=new LinkedList<Employee>();
		L1.add(e1);
		L1.add(e2);
		L1.add(e3);
	
	
		for(Employee e:L1)
		{
			System.out.println(e.getEmpid()+"\t"+e.getEname()+"\t"+e.getAddress());
			
		}
	}
}