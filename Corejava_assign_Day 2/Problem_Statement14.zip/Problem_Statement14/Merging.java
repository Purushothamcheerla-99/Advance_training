package Problem_Statement14;

import java.util.Scanner;

public class Merging {

    public static void main(String[] args) {

        //1
        int array1_size, array2_size;

        //2
        int arr1[], arr2[], result[];

        //3
        Scanner scanner = new Scanner(System.in);

        //4
        System.out.print("Enter the length of the array a : ");

        //5
        array1_size = scanner.nextInt();

        //6
        System.out.print("Enter the length of the array b : ");
        array2_size = scanner.nextInt();

        //7
        arr1 = new int[array1_size];
        arr2 = new int[array2_size];
        result = new int[array1_size + array2_size];


        //8
        System.out.println("Enter elements for the  array a :");

        for (int i = 0; i < array1_size; i++) {
            System.out.println("Enter element " + (i + 1) + " : ");
            arr1[i] = scanner.nextInt();
        }

        //9
        System.out.println("Enter elements for the array b :");

        for (int i = 0; i < array2_size; i++) {
            System.out.println("Enter element " + (i + 1) + " : ");
            arr2[i] = scanner.nextInt();
        }

        //10
        for (int i = 0; i < array1_size + array2_size; i++) {
            //11
            if (i < array1_size) {
                result[i] = arr1[i];
            } else {
                result[i] = arr2[i - array1_size];
            }
        }


        //12
        System.out.println("Merge list is : ");

        for (int i = 0; i < array1_size + array2_size; i++) {
            System.out.print(result[i] + " ");
        }
    }

}